import os
import re
import json
import time
import random
import tempfile
import argparse
import platform
import psutil
import shutil
import signal
from pathlib import Path
from datetime import datetime, timedelta
from functools import lru_cache
from threading import Lock, Thread
from subprocess import Popen, PIPE

import requests
import schedule
from dotenv import load_dotenv
from loguru import logger
from selenium import webdriver
from selenium.webdriver import DesiredCapabilities
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    NoSuchElementException, ElementNotInteractableException,
    TimeoutException, WebDriverException, StaleElementReferenceException
)
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.core.utils import ChromeType

# 加载环境变量 & 自动备份配置文件
load_dotenv(override=True)
BASE_DIR = Path(__file__).parent
ENV_FILE = BASE_DIR / ".env"
ENV_BACKUP_FILE = BASE_DIR / ".env.backup"
# 首次启动自动备份配置，防止配置丢失
if ENV_FILE.exists() and not ENV_BACKUP_FILE.exists():
    shutil.copy(ENV_FILE, ENV_BACKUP_FILE)
    logger.info("配置文件已自动备份至 .env.backup")

# 初始化全局锁 & 状态标识
FILE_LOCK = Lock()  # 文件操作锁
PROCESS_LOCK = Lock()  # 进程操作锁
RESTART_FLAG = False  # 程序重启标识
MIN_DISK_SPACE = 500  # 磁盘最小剩余空间(MB)，低于则自动清理

# 配置类（新增云码API配置，支持双API切换）
class Config:
    # ===================== 验证码API核心配置（二选一，优先云码）=====================
    VERIFY_API_TYPE = os.getenv("VERIFY_API_TYPE", "jfbym").lower()  # 可选：jfbym（云码）/jianshu（建数）
    # 云码API配置（https://jfbym.com/demo.html）
    JFBYM_API_URL = os.getenv("JFBYM_API_URL", "https://api.jfbym.com/api/YmServer/customApi")
    JFBYM_USERNAME = os.getenv("JFBYM_USERNAME", "")  # 云码账号
    JFBYM_PASSWORD = os.getenv("JFBYM_PASSWORD", "")  # 云码密码
    JFBYM_SOFT_ID = os.getenv("JFBYM_SOFT_ID", "91004")  # 云码软件ID（默认通用版）
    JFBYM_SOFT_KEY = os.getenv("JFBYM_SOFT_KEY", "a40f794163d86d33f8121d19d119f090")  # 云码软件KEY（默认通用版）
    JFBYM_CAPTCHA_TYPE = os.getenv("JFBYM_CAPTCHA_TYPE", "1011")  # 验证码类型：1011=普通字符验证码（默认）
    JFBYM_TIMEOUT = int(os.getenv("JFBYM_TIMEOUT", 60))  # 云码识别超时时间（秒）
    # 建数数据API配置（兼容旧版）
    JIANSHU_API_URL = os.getenv("JIANSHU_API_URL", "http://apigateway.jianjiaoshuju.com/api/v_1/yzmCustomized.html")
    JIANSHU_HEADERS = {
        "appCode": os.getenv("JIANSHU_APP_CODE", ""),
        "appKey": os.getenv("JIANSHU_APP_KEY", ""),
        "appSecret": os.getenv("JIANSHU_APP_SECRET", "")
    }
    # 通用验证码配置
    VERIFY_RETRY_TIMES = int(os.getenv("VERIFY_RETRY_TIMES", 3))  # 识别失败重试次数
    VERIFY_CODE_MIN_LEN = int(os.getenv("VERIFY_CODE_MIN_LEN", 4))  # 验证码最小长度（过滤无效结果）

    # ===================== Outlook注册核心配置 =====================
    SIGNUP_URL = os.getenv("OUTLOOK_SIGNUP_URL", "https://signup.live.com/signup")
    CHECK_TIMEOUT_INIT = float(os.getenv("CHECK_TIMEOUT_INIT", 1.5))
    MAX_BAD_PROXY_RATIO = float(os.getenv("MAX_BAD_PROXY_RATIO", 0.6))
    CONSECUTIVE_FAIL_LIMIT = int(os.getenv("CONSECUTIVE_FAIL_LIMIT", 15))
    ANTI_BLOCK_DELAY = (float(os.getenv("ANTI_BLOCK_MIN_DELAY", 2.0)),
                        float(os.getenv("ANTI_BLOCK_MAX_DELAY", 5.0)))

    # ===================== 网络请求配置 =====================
    REQ_HEADERS_LIST = [
        {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate',
            'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
            'cache-control': 'max-age=0',
            'dnt': '1',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        },
        {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate',
            'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
            'cache-control': 'max-age=0',
            'dnt': '1',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
        },
        {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate',
            'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
            'cache-control': 'max-age=0',
            'dnt': '1',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
        }
    ]

    # ===================== 注册基础数据 =====================
    SIGN_LIST = ['~', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '<', '>', '?', ':', '{', '}', '|']
    NAME_LIST = ['Emma', 'Olivia', 'Ava', 'Isabella', 'Sophia', 'Charlotte', 'Mia', 'Amelia', 'Harper', 'Evelyn']
    BIRTH_YEAR_RANGE = (1980, 2000)
    BIRTH_MONTH_RANGE = (1, 12)
    BIRTH_DAY_RANGE = (1, 28)

    # ===================== 浏览器配置 =====================
    WINDOW_SIZE = (700, 600)
    PAGE_LOAD_STRATEGY = "none"
    HEADLESS = os.getenv("HEADLESS", "True").lower() == "true"
    ANDROID_CHROME_DRIVER = os.getenv("ANDROID_CHROME_DRIVER", "/sdcard/chromedriver")
    ANDROID_CHROME_BIN = os.getenv("ANDROID_CHROME_BIN", "/data/app/com.android.chrome/chrome")

    # ===================== 自动清理配置 =====================
    LOG_RETENTION_DAYS = int(os.getenv("LOG_RETENTION_DAYS", 3))
    USED_IP_CLEAN_DAYS = int(os.getenv("USED_IP_CLEAN_DAYS", 1))

    # ===================== 进程守护配置 =====================
    DAEMON_INTERVAL = int(os.getenv("DAEMON_INTERVAL", 10))

# 全局文件路径定义
PASS_FILE = BASE_DIR / "pass.txt"
USED_IP_FILE = BASE_DIR / "used_ip.txt"
TIMEOUT_FILE = BASE_DIR / "check_timeout.txt"
LOG_FILE = BASE_DIR / os.getenv("LOG_FILE", "outlook_register.log")
ERROR_LOG_FILE = BASE_DIR / "error.log"

# 初始化日志（运行日志/错误日志分离）
logger.remove()
logger.add(
    LOG_FILE,
    level=os.getenv("LOG_LEVEL", "INFO"),
    rotation="10MB",
    retention=f"{Config.LOG_RETENTION_DAYS} days",
    encoding="utf-8",
    enqueue=True,
    filter=lambda record: record["level"].name != "ERROR"
)
logger.add(
    ERROR_LOG_FILE,
    level="ERROR",
    rotation="5MB",
    retention=f"{Config.LOG_RETENTION_DAYS} days",
    encoding="utf-8",
    enqueue=True
)

# 全局工具函数
def is_android() -> bool:
    """检测是否为安卓环境（CJ_IDE/Pydroid 3）"""
    return platform.system() == "Linux" and "android" in platform.uname().release.lower()

def get_free_disk_space() -> int:
    """获取当前磁盘剩余空间(MB)"""
    disk = shutil.disk_usage(BASE_DIR)
    return disk.free // 1024 // 1024

def random_headers() -> dict:
    """随机获取请求头，降低风控概率"""
    return random.choice(Config.REQ_HEADERS_LIST)

class OutlookAutoRegister:
    """Outlook全自动注册核心类 - 云码API集成版"""
    def __init__(self):
        # 实例变量
        self.check_timeout = Config.CHECK_TIMEOUT_INIT
        self.last_image_data = ""
        self.last_code = ""
        self.consecutive_fail = 0
        self.used_ips = self._load_used_ips()
        self.success_accounts = self._load_success_accounts()
        self.running = True
        # 云码API状态标识
        self.jfbym_balance = -1  # 云码余额（-1=未检测）

    def _load_used_ips(self) -> set:
        """加载已使用的代理IP"""
        if USED_IP_FILE.exists():
            try:
                with open(USED_IP_FILE, "r", encoding="utf-8") as f:
                    return set(f.read().splitlines())
            except Exception as e:
                logger.error(f"加载已用IP失败：{e}")
        return set()

    def _load_success_accounts(self) -> set:
        """加载已注册成功的账号（去重）"""
        if PASS_FILE.exists():
            try:
                with open(PASS_FILE, "r", encoding="utf-8") as f:
                    return set([line.split()[0].strip() for line in f.read().splitlines() if line.strip()])
            except Exception as e:
                logger.error(f"加载成功账号失败：{e}")
        return set()

    def _save_used_ip(self, ip: str):
        """保存已用IP"""
        if ip not in self.used_ips and ip.strip():
            self.used_ips.add(ip)
            with FILE_LOCK:
                with open(USED_IP_FILE, "a+", encoding="utf-8") as f:
                    f.write(f"{ip}\n")

    def _save_success_account(self, email: str, pwd: str):
        """保存成功账号（去重）"""
        if email not in self.success_accounts and email.strip() and pwd.strip():
            self.success_accounts.add(email)
            with FILE_LOCK:
                with open(PASS_FILE, "a+", encoding="utf-8") as f:
                    f.write(f"{email} {pwd}\n")
            logger.success(f"注册成功，账号已保存：{email}")

    def _save_timeout(self, timeout: float):
        """保存超时时间"""
        with FILE_LOCK:
            with open(TIMEOUT_FILE, "w", encoding="utf-8") as f:
                now = datetime.now()
                f.write(f"{now.year} {now.month} {now.day} {now.hour} {timeout}")

    def _load_timeout(self):
        """加载当天超时时间"""
        if not TIMEOUT_FILE.exists():
            return
        try:
            with open(TIMEOUT_FILE, "r", encoding="utf-8") as f:
                parts = f.read().split()
                if len(parts) != 5:
                    return
                year, month, day, hour, timeout = int(parts[0]), int(parts[1]), int(parts[2]), int(parts[3]), float(parts[4])
                now = datetime.now()
                if (now.year, now.month, now.day, now.hour) == (year, month, day, hour):
                    self.check_timeout = timeout
                    logger.info(f"加载当天超时时间：{self.check_timeout}s")
        except Exception as e:
            logger.warning(f"加载超时时间失败：{e}")

    def _auto_clean(self):
        """自动清理过期资源"""
        try:
            # 磁盘空间不足时清理
            if get_free_disk_space() < MIN_DISK_SPACE:
                logger.warning(f"磁盘剩余空间不足{MIN_DISK_SPACE}MB，开始自动清理")
                self._clean_expired_used_ips()
                if ERROR_LOG_FILE.exists():
                    with open(ERROR_LOG_FILE, "w", encoding="utf-8") as f:
                        f.write("")
                logger.info(f"自动清理完成，剩余空间：{get_free_disk_space()}MB")
            # 每天0点清理过期IP
            if datetime.now().hour == 0 and datetime.now().minute == 0:
                self._clean_expired_used_ips()
        except Exception as e:
            logger.error(f"自动清理失败：{e}")

    def _clean_expired_used_ips(self):
        """清理过期已用IP"""
        try:
            if not USED_IP_FILE.exists():
                return
            file_ctime = datetime.fromtimestamp(USED_IP_FILE.stat().st_ctime)
            if (datetime.now() - file_ctime).days >= Config.USED_IP_CLEAN_DAYS:
                with FILE_LOCK:
                    open(USED_IP_FILE, "w", encoding="utf-8").close()
                self.used_ips = set()
                logger.info(f"清理过期已用IP，保留天数：{Config.USED_IP_CLEAN_DAYS}天")
        except Exception as e:
            logger.error(f"清理过期IP失败：{e}")

    def _check_jfbym_balance(self) -> bool:
        """检测云码API余额（仅检测一次）"""
        if self.jfbym_balance != -1:
            return self.jfbym_balance > 0
        if not all([Config.JFBYM_USERNAME, Config.JFBYM_PASSWORD]):
            logger.error("云码API配置不完整：请填写用户名和密码")
            return False
        try:
            # 云码余额查询接口
            balance_url = "https://api.jfbym.com/api/User/checkBalance"
            data = {
                "username": Config.JFBYM_USERNAME,
                "password": Config.JFBYM_PASSWORD
            }
            resp = requests.post(balance_url, json=data, timeout=10)
            resp.raise_for_status()
            result = resp.json()
            if result.get("code") == 10000:
                self.jfbym_balance = float(result.get("data", {}).get("balance", 0))
                logger.info(f"云码API余额检测成功：{self.jfbym_balance}元")
                if self.jfbym_balance <= 0:
                    logger.error("云码API余额不足，请充值后再运行")
                    return False
                return True
            else:
                logger.error(f"云码余额查询失败：{result.get('msg', '未知错误')}")
                return False
        except Exception as e:
            logger.error(f"云码余额检测异常：{e}")
            return False

    def _env_check(self) -> bool:
        """前置环境自检（新增云码API检测）"""
        logger.info("开始执行环境自检...")
        check_items = ["Chrome浏览器", "ChromeDriver", "网络连通性", "验证码API", "代理IP"]
        check_result = True

        # 1. Chrome浏览器检测
        try:
            if is_android():
                if os.path.exists(Config.ANDROID_CHROME_BIN):
                    logger.info("✅ 安卓环境 - Chrome内核检测通过")
                else:
                    logger.error("❌ 安卓环境 - 未找到Chrome内核")
                    check_result = False
            else:
                chrome_exe = "chrome.exe" if platform.system() == "Windows" else "google-chrome"
                Popen([chrome_exe, "--version"], stdout=PIPE, stderr=PIPE)
                logger.info("✅ Chrome浏览器检测通过")
        except Exception as e:
            logger.error(f"❌ Chrome浏览器检测失败：{e}")
            check_result = False

        # 2. ChromeDriver检测
        try:
            if is_android() and os.path.exists(Config.ANDROID_CHROME_DRIVER):
                logger.info("✅ 安卓环境 - ChromeDriver检测通过")
            elif not is_android():
                ChromeDriverManager().install()
                logger.info("✅ ChromeDriver检测通过（自动适配版本）")
            else:
                logger.error("❌ 安卓环境 - 未找到ChromeDriver")
                check_result = False
        except Exception as e:
            logger.error(f"❌ ChromeDriver检测失败：{e}")
            check_result = False

        # 3. 网络连通性检测
        try:
            resp = requests.get(Config.SIGNUP_URL, headers=random_headers(), timeout=10)
            if resp.status_code in [200, 302, 301]:
                logger.info("✅ 网络连通性 - 可访问Outlook注册页")
            else:
                logger.error(f"❌ 网络连通性 - 状态码：{resp.status_code}")
                check_result = False
        except Exception as e:
            logger.error(f"❌ 网络连通性检测失败：{e}")
            check_result = False

        # 4. 验证码API检测（双API适配）
        try:
            if Config.VERIFY_API_TYPE == "jfbym":
                # 云码API检测
                if self._check_jfbym_balance():
                    logger.info("✅ 验证码API - 云码API配置正常且余额充足")
                else:
                    logger.error("❌ 验证码API - 云码API配置错误或余额不足")
                    check_result = False
            else:
                # 建数数据API检测
                if all(Config.JIANSHU_HEADERS.values()):
                    resp = requests.get(Config.JIANSHU_API_URL.split("/api/")[0], headers=random_headers(), timeout=5)
                    if resp.status_code in [200, 404]:
                        logger.info("✅ 验证码API - 建数数据API可访问")
                    else:
                        logger.error(f"❌ 验证码API - 建数数据API不可访问")
                        check_result = False
                else:
                    logger.error("❌ 验证码API - 建数数据API配置不完整")
                    check_result = False
        except Exception as e:
            logger.error(f"❌ 验证码API检测失败：{e}")
            check_result = False

        # 5. 代理IP检测
        try:
            test_proxy = self.get_proxy_list()[:1]
            if test_proxy:
                logger.info("✅ 代理IP - 可拉取到有效代理")
            else:
                logger.warning("⚠️  代理IP - 暂未拉取到有效代理，运行时将重试")
        except Exception as e:
            logger.warning(f"⚠️  代理IP检测暂未通过：{e}")

        logger.info("环境自检完成\n" + "="*50)
        return check_result

    def wait_for_element(self, driver, by: By, value: str, timeout: float = None, retry: int = 2) -> object:
        """通用元素等待（带重试）"""
        timeout = timeout or self.check_timeout
        for _ in range(retry + 1):
            try:
                return WebDriverWait(driver, timeout).until(
                    EC.presence_of_element_located((by, value))
                )
            except (TimeoutException, StaleElementReferenceException):
                time.sleep(random.uniform(0.5, 1.0))
                continue
        logger.error(f"元素定位失败：{by}={value}")
        return None

    def wait_for_elements(self, driver, by: By, value: str, target_num: int = None, timeout: float = None) -> list:
        """通用多元素等待"""
        timeout = timeout or self.check_timeout
        try:
            elements = WebDriverWait(driver, timeout).until(
                EC.presence_of_all_elements_located((by, value))
            )
            if target_num and len(elements) != target_num:
                logger.warning(f"元素数量不符：期望{target_num}，实际{len(elements)}")
                return []
            return elements
        except TimeoutException:
            logger.error(f"多元素定位失败：{by}={value}")
            return []

    def _verify_code_jfbym(self, img_data: str) -> str:
        """
        云码API验证码识别（核心新增功能）
        文档参考：https://jfbym.com/demo.html
        :param img_data: 图片base64编码（不含前缀）
        :return: 识别结果/空字符串
        """
        # 相同图片直接返回上次结果
        if img_data == self.last_image_data and self.last_code:
            return self.last_code
        self.last_image_data = img_data

        # 校验云码配置
        if not all([Config.JFBYM_USERNAME, Config.JFBYM_PASSWORD, Config.JFBYM_SOFT_ID, Config.JFBYM_SOFT_KEY]):
            logger.error("云码API配置不完整，无法识别验证码")
            return ""

        # 云码API请求参数
        data = {
            "username": Config.JFBYM_USERNAME,
            "password": Config.JFBYM_PASSWORD,
            "softid": Config.JFBYM_SOFT_ID,
            "softkey": Config.JFBYM_SOFT_KEY,
            "image": img_data,
            "typeid": Config.JFBYM_CAPTCHA_TYPE,
            "timeout": Config.JFBYM_TIMEOUT
        }

        # 识别重试
        for retry in range(Config.VERIFY_RETRY_TIMES):
            try:
                resp = requests.post(
                    Config.JFBYM_API_URL,
                    json=data,
                    timeout=Config.JFBYM_TIMEOUT + 10
                )
                resp.raise_for_status()
                result = resp.json()
                logger.debug(f"云码API返回结果（第{retry+1}次）：{result}")

                # 处理返回结果（参考云码API文档）
                if result.get("code") == 10000:
                    code = result.get("data", {}).get("recognition", "").strip()
                    # 校验识别结果（长度过滤）
                    if len(code) >= Config.VERIFY_CODE_MIN_LEN:
                        self.last_code = code
                        logger.info(f"云码API识别成功（第{retry+1}次）：{code}")
                        return code
                    else:
                        logger.warning(f"云码识别结果无效（长度不足）：{code}")
                elif result.get("code") == 10001:
                    logger.error("云码API - 账号密码错误")
                    break
                elif result.get("code") == 10002:
                    logger.error("云码API - 余额不足")
                    self.jfbym_balance = 0
                    break
                elif result.get("code") == 10003:
                    logger.warning(f"云码API - 识别超时，重试中...")
                    time.sleep(2)
                    continue
                else:
                    logger.error(f"云码API识别失败（第{retry+1}次）：{result.get('msg', '未知错误')}")
            except Exception as e:
                logger.error(f"云码API调用异常（第{retry+1}次）：{e}")
                time.sleep(random.uniform(1.0, 2.0))
                continue

        logger.error(f"云码API识别重试{Config.VERIFY_RETRY_TIMES}次均失败")
        self.last_code = ""
        return ""

    def _verify_code_jianshu(self, img_data: str) -> str:
        """兼容旧版：建数数据API验证码识别"""
        if img_data == self.last_image_data and self.last_code:
            return self.last_code
        self.last_image_data = img_data

        for retry in range(Config.VERIFY_RETRY_TIMES):
            try:
                data = {"v_pic": img_data, "pri_id": "ne"}
                resp = requests.post(
                    Config.JIANSHU_API_URL,
                    headers=Config.JIANSHU_HEADERS,
                    data=data,
                    timeout=self.check_timeout * 3
                )
                resp.raise_for_status()
                result = resp.json()
                code = result.get("v_code", "").strip()
                if code and len(code) >= Config.VERIFY_CODE_MIN_LEN:
                    self.last_code = code
                    logger.info(f"建数API识别成功（第{retry+1}次）：{code}")
                    return code
                else:
                    logger.warning(f"建数API识别结果无效：{code}")
            except Exception as e:
                logger.error(f"建数API识别失败（第{retry+1}次）：{e}")
                time.sleep(random.uniform(1.0, 2.0))
                continue

        logger.error(f"建数API识别重试{Config.VERIFY_RETRY_TIMES}次均失败")
        self.last_code = ""
        return ""

    @lru_cache(maxsize=10)
    def get_verification_code(self, img_data: str) -> str:
        """
        统一验证码识别入口（自动切换双API）
        :param img_data: 图片base64编码（含前缀需处理）
        :return: 识别结果
        """
        # 移除base64前缀（如果有）
        if img_data.startswith("data:image/"):
            img_data = img_data.split(",")[-1]

        # 按配置选择API
        if Config.VERIFY_API_TYPE == "jfbym":
            return self._verify_code_jfbym(img_data)
        else:
            return self._verify_code_jianshu(img_data)

    def _detect_proxy_timeout(self, ip_list: list):
        """动态检测代理超时时间"""
        if not ip_list:
            raise ValueError("代理列表为空")
        max_bad = int(len(ip_list) * Config.MAX_BAD_PROXY_RATIO) or 1
        bad_num, success_num = 0, 0
        test_ip_list = ip_list[-5:]

        for ip, port, tp in test_ip_list:
            tp = tp.lower()
            proxy = {tp: f"{tp}://{ip}:{port}"}
            try:
                requests.get(
                    Config.SIGNUP_URL,
                    headers=random_headers(),
                    proxies=proxy,
                    timeout=self.check_timeout,
                    allow_redirects=False
                )
                success_num += 1
            except Exception:
                bad_num += 1
            logger.debug(f"代理超时测试：{self.check_timeout}s | 成功：{success_num} | 失败：{bad_num}")

            if bad_num > max_bad:
                self.check_timeout += 1.5
                if self.check_timeout >= 15:
                    raise TimeoutError("代理超时时间超过15s")
                logger.warning(f"调整超时时间为{self.check_timeout}s")
                return self._detect_proxy_timeout(ip_list)
            if success_num >= len(test_ip_list) - max_bad:
                self._save_timeout(self.check_timeout)
                return

    def get_proxy_list(self) -> list:
        """获取有效代理IP列表"""
        self._load_timeout()
        ip_list = []
        for hour_offset in range(0, 12):
            now = datetime.now()
            current_hour = now.hour - hour_offset
            if current_hour < 0:
                current_hour += 24
            cur_url = f"https://ip.ihuan.me/today/{now.year}/{now.month:02d}/{now.day:02d}/{current_hour:02d}.html"
            try:
                resp = requests.get(cur_url, headers=random_headers(), timeout=8)
                resp.raise_for_status()
                ip_list = re.findall(r'<br>([\d\.]*?):(\d*)@(.*?)#', resp.text, re.S)
                if ip_list:
                    logger.info(f"从{cur_url}获取到{len(ip_list)}个代理IP")
                    break
            except Exception as e:
                logger.debug(f"拉取{cur_url}代理失败：{e}")
                time.sleep(1.0)
                continue

        if not ip_list:
            raise Exception("12小时内未找到有效代理IP，5分钟后重试")

        ip_list = [item for item in ip_list if item[0] not in self.used_ips]
        if not ip_list:
            with FILE_LOCK:
                open(USED_IP_FILE, "w", encoding="utf-8").close()
            self.used_ips = set()
            raise Exception("所有代理IP均已使用，已清空并重新拉取")

        if not TIMEOUT_FILE.exists():
            self._detect_proxy_timeout(ip_list)

        return [[tp.lower(), f"{ip}:{port}"] for ip, port, tp in ip_list]

    def generate_email_pwd(self) -> (str, str):
        """生成账号密码"""
        def random_char(is_lower: bool = None) -> str:
            if is_lower is None:
                is_lower = random.choice([True, False])
            return chr(random.randint(97, 122)) if is_lower else chr(random.randint(65, 90))

        def random_digit() -> str: return str(random.randint(0, 9))
        def random_sign() -> str: return random.choice(Config.SIGN_LIST)

        # 邮箱前缀
        email_len = random.randint(5, 8)
        email_parts = [random.choice([random_char(), random_digit()]) for _ in range(email_len)]
        email = "".join(email_parts)

        # 密码
        pwd_parts = [
            random_char(False), random_char(True), random_digit(), random_sign(),
            random_char(False), random_char(True), random_digit(), random_sign()
        ]
        for _ in range(random.randint(0, 2)):
            pwd_parts.append(random.choice([random_char(), random_digit()]))
        random.shuffle(pwd_parts)
        pwd = "".join(pwd_parts)

        return email, pwd

    def create_chrome_driver(self, proxy_type: str, proxy_addr: str) -> webdriver.Chrome:
        """创建Chrome驱动（适配多环境）"""
        chrome_options = Options()
        desired_caps = DesiredCapabilities.CHROME
        desired_caps["pageLoadStrategy"] = Config.PAGE_LOAD_STRATEGY

        # 通用配置
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--disable-images")
        chrome_options.add_argument("--disable-javascript")
        chrome_options.add_argument("--window-size={},{}".format(*Config.WINDOW_SIZE))
        chrome_options.add_argument(f"--proxy-server={proxy_type}://{proxy_addr}")
        chrome_options.add_argument(f"user-agent={random_headers()['user-agent']}")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])
        chrome_options.add_experimental_option("useAutomationExtension", False)

        # 无头模式
        if Config.HEADLESS:
            chrome_options.add_argument("--headless=new")
            logger.info("Chrome以无头模式运行")

        # 安卓环境适配
        if is_android():
            chrome_options.binary_location = Config.ANDROID_CHROME_BIN
            driver = webdriver.Chrome(
                executable_path=Config.ANDROID_CHROME_DRIVER,
                options=chrome_options,
                desired_capabilities=desired_caps
            )
            logger.info("适配安卓CJ_IDE环境")
        else:
            driver = webdriver.Chrome(
                executable_path=ChromeDriverManager().install(),
                options=chrome_options,
                desired_capabilities=desired_caps
            )

        # 防检测
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        driver.user_data_dir = tempfile.mkdtemp(prefix="outlook_auto_")
        return driver

    def clean_driver(self, driver: webdriver.Chrome):
        """清理驱动资源"""
        try:
            if not driver:
                return
            driver.quit()
            # 杀死残留进程
            for proc in psutil.process_iter(["name", "cmdline"]):
                try:
                    if "chrome" in proc.name().lower() or "chromium" in proc.name().lower():
                        if hasattr(driver, "user_data_dir") and driver.user_data_dir in " ".join(proc.cmdline()):
                            proc.kill()
                except Exception:
                    continue
            shutil.rmtree(driver.user_data_dir, ignore_errors=True)
            logger.debug("驱动资源清理完成")
        except Exception as e:
            logger.warning(f"驱动清理失败：{e}")

    def register(self, driver: webdriver.Chrome, email: str, pwd: str) -> str | bool:
        """核心注册流程"""
        full_email = f"{email}@outlook.com"
        if full_email in self.success_accounts:
            logger.warning(f"账号已存在，跳过：{full_email}")
            return "exist"

        try:
            # 1. 打开注册页，切换到Outlook
            driver.get(Config.SIGNUP_URL)
            live_switch = self.wait_for_element(driver, By.CSS_SELECTOR, "#liveSwitch")
            if not live_switch:
                return False
            live_switch.click()
            logger.info(f"开始注册：{full_email}")
            time.sleep(random.uniform(*Config.ANTI_BLOCK_DELAY))

            # 2. 输入邮箱前缀
            email_input = self.wait_for_element(driver, By.CSS_SELECTOR, "#MemberName")
            if not email_input:
                return False
            email_input.clear()
            email_input.send_keys(email)
            self.wait_for_element(driver, By.CSS_SELECTOR, "#iSignupAction").click()
            time.sleep(random.uniform(*Config.ANTI_BLOCK_DELAY))

            # 3. 等待密码页面
            WebDriverWait(driver, self.check_timeout * 15).until(
                lambda d: "Create a password" in d.title or "创建密码" in d.title
            )

            # 4. 输入密码
            pwd_input = self.wait_for_element(driver, By.CSS_SELECTOR, "#PasswordInput")
            optin_email = self.wait_for_element(driver, By.CSS_SELECTOR, "#iOptinEmail")
            submit = self.wait_for_element(driver, By.CSS_SELECTOR, "#iSignupAction")
            if not all([pwd_input, optin_email, submit]):
                return False
            pwd_input.send_keys(pwd)
            optin_email.click()
            submit.click()
            time.sleep(random.uniform(*Config.ANTI_BLOCK_DELAY))

            # 5. 填写姓名
            last_name = self.wait_for_element(driver, By.CSS_SELECTOR, "#LastName")
            first_name = self.wait_for_element(driver, By.CSS_SELECTOR, "#FirstName")
            submit = self.wait_for_element(driver, By.CSS_SELECTOR, "#iSignupAction")
            if not all([last_name, first_name, submit]):
                return False
            last_name.send_keys(random.choice(Config.NAME_LIST))
            first_name.send_keys(random.choice(Config.NAME_LIST))
            submit.click()
            time.sleep(random.uniform(*Config.ANTI_BLOCK_DELAY))

            # 6. 填写生日
            year = random.randint(*Config.BIRTH_YEAR_RANGE)
            month = random.randint(*Config.BIRTH_MONTH_RANGE)
            day = random.randint(*Config.BIRTH_DAY_RANGE)
            year_elem = self.wait_for_element(driver, By.CSS_SELECTOR, f"#BirthYear option[value='{year}']")
            month_elem = self.wait_for_element(driver, By.CSS_SELECTOR, f"#BirthMonth option[value='{month}']")
            day_elem = self.wait_for_element(driver, By.CSS_SELECTOR, f"#BirthDay option[value='{day}']")
            submit = self.wait_for_element(driver, By.CSS_SELECTOR, "#iSignupAction")
            if not all([year_elem, month_elem, day_elem, submit]):
                return False
            year_elem.click()
            month_elem.click()
            day_elem.click()
            submit.click()
            time.sleep(random.uniform(*Config.ANTI_BLOCK_DELAY))

            # 7. 验证码处理
            current_url = driver.current_url
            code_inputs = self.wait_for_elements(driver, By.TAG_NAME, "input", 5)
            code_imgs = self.wait_for_elements(driver, By.TAG_NAME, "img", 5)
            submit = self.wait_for_element(driver, By.CSS_SELECTOR, "#iSignupAction")
            if not all([code_inputs, code_imgs, submit]):
                return False
            code_input = code_inputs[0]
            code_img = code_imgs[-1]

            # 识别验证码
            code = self.get_verification_code(code_img.screenshot_as_base64)
            if not code:
                return False
            code_input.clear()
            code_input.send_keys(code)
            submit.click()
            time.sleep(random.uniform(*Config.ANTI_BLOCK_DELAY))

            # 8. 验证结果
            WebDriverWait(driver, self.check_timeout * 8).until(
                lambda d: d.current_url != current_url
            )
            if "account.microsoft.com" in driver.current_url:
                self._save_success_account(full_email, pwd)
                return "success"
            return False

        except TimeoutException:
            logger.error(f"注册超时：{full_email}")
            return False
        except NoSuchElementException as e:
            logger.error(f"元素缺失：{e} | {full_email}")
            return False
        except Exception as e:
            if "already exists" in str(e).lower():
                logger.warning(f"邮箱已存在：{full_email}")
                return "exist"
            logger.error(f"注册异常：{e} | {full_email}")
            return False

    def process_daemon(self):
        """进程守护线程"""
        logger.info(f"进程守护已启动，每{Config.DAEMON_INTERVAL}秒检查一次")
        while self.running:
            try:
                # 风控检测：连续失败过多则暂停
                if self.consecutive_fail >= Config.CONSECUTIVE_FAIL_LIMIT:
                    logger.warning(f"连续失败{Config.CONSECUTIVE_FAIL_LIMIT}次，暂停10分钟")
                    self.consecutive_fail = 0
                    time.sleep(600)
                # 云码余额检测：余额不足则暂停
                if Config.VERIFY_API_TYPE == "jfbym" and self.jfbym_balance == 0:
                    logger.error("云码API余额不足，暂停运行")
                    self.running = False
                    break
                # 自动清理
                self._auto_clean()
            except Exception as e:
                logger.error(f"进程守护异常：{e}")
            finally:
                time.sleep(Config.DAEMON_INTERVAL)

    def run_single(self, proxy_type: str, proxy_addr: str) -> bool:
        """单代理单次注册"""
        driver = None
        proxy_ip = proxy_addr.split(":")[0]
        try:
            driver = self.create_chrome_driver(proxy_type, proxy_addr)
            email, pwd = self.generate_email_pwd()
            result = self.register(driver, email, pwd)
            if result == "success":
                self.consecutive_fail = 0
                self._save_used_ip(proxy_ip)
                return True
            elif result == "exist":
                self._save_used_ip(proxy_ip)
                return False
            else:
                self.consecutive_fail += 1
                self._save_used_ip(proxy_ip)
                return False
        except Exception as e:
            self.consecutive_fail += 1
            logger.error(f"单代理注册失败：{proxy_addr} | {e}")
            return False
        finally:
            self.clean_driver(driver)
            time.sleep(random.uniform(*Config.ANTI_BLOCK_DELAY))

    def main_run(self):
        """主运行逻辑"""
        global RESTART_FLAG
        # 环境自检
        if not self._env_check():
            logger.error("环境自检失败，退出程序")
            self.running = False
            return

        # 启动守护线程
        daemon_thread = Thread(target=self.process_daemon, daemon=True)
        daemon_thread.start()

        logger.info("Outlook全自动注册程序（云码API版）已启动，无人值守模式...")
        while self.running:
            try:
                proxy_list = self.get_proxy_list()
                for proxy_type, proxy_addr in proxy_list:
                    if not self.running or RESTART_FLAG:
                        break
                    if datetime.now().minute == 10 or get_free_disk_space() < MIN_DISK_SPACE:
                        logger.info("触发停止条件，进入下一轮")
                        break
                    self.run_single(proxy_type, proxy_addr)
            except Exception as e:
                logger.error(f"主运行异常，30秒后重试：{e}")
                time.sleep(30)
                continue

        logger.info("程序已停止运行")
        RESTART_FLAG = False

def signal_handler(signum, frame):
    """信号处理：优雅退出"""
    global RESTART_FLAG
    logger.info("检测到停止信号，正在优雅退出...")
    if 'register' in locals():
        register.running = False
    RESTART_FLAG = False
    time.sleep(5)
    logger.info("程序已退出")
    exit(0)

# 注册信号
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

def main():
    """程序入口"""
    parser = argparse.ArgumentParser(description="Outlook邮箱全自动注册工具（云码API集成版）")
    parser.add_argument("--once", action="store_true", help="单次运行（测试用）")
    args = parser.parse_args()

    global register
    register = OutlookAutoRegister()

    if args.once:
        logger.info("进入单次运行模式（测试用）")
        register._env_check()
        try:
            proxy_list = register.get_proxy_list()[:1]
            register.run_single(*proxy_list[0])
        except Exception as e:
            logger.error(f"单次运行失败：{e}")
        finally:
            register.running = False
    else:
        while True:
            register.main_run()
            if RESTART_FLAG:
                logger.info("程序重新启动中...")
                register = OutlookAutoRegister()
            else:
                break

if __name__ == "__main__":
    main()
